import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Car, Clock, Shield, Star, Users, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
const HomePage = () => {
  const navigate = useNavigate();
  const features = [{
    icon: Car,
    title: 'Premium Fleet',
    description: 'Luxury cars with professional drivers'
  }, {
    icon: Clock,
    title: '24/7 Service',
    description: 'Round-the-clock availability'
  }, {
    icon: Shield,
    title: 'Safe & Secure',
    description: 'Fully insured and verified drivers'
  }, {
    icon: Star,
    title: 'Top Rated',
    description: '5-star customer satisfaction'
  }];
  return <div className="min-h-screen">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 glass-effect">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <motion.div initial={{
          opacity: 0,
          x: -20
        }} animate={{
          opacity: 1,
          x: 0
        }} className="text-2xl font-bold gradient-text">
            CarBook Pro
          </motion.div>
          
          <div className="flex gap-4">
            <Button variant="ghost" onClick={() => navigate('/admin/login')} className="text-white hover:bg-white/10">
              Admin
            </Button>
            <Button onClick={() => navigate('/book')} className="btn-primary">
              Book Now
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-20 pb-16 px-4">
        <div className="container mx-auto text-center">
          <motion.div initial={{
          opacity: 0,
          y: 30
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          duration: 0.8
        }} className="max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-7xl font-bold mb-6 gradient-text">Chitrakoot Tour And Travels</h1>
            <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-2xl mx-auto">
              Experience luxury travel with our premium fleet and professional drivers. Book your ride in minutes.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button onClick={() => navigate('/book')} className="btn-primary text-lg px-8 py-4">
                <Car className="mr-2 h-5 w-5" />
                Book Your Ride
              </Button>
              <Button variant="outline" className="text-lg px-8 py-4 border-white/30 text-white hover:bg-white/10">
                <Users className="mr-2 h-5 w-5" />
                Learn More
              </Button>
            </div>
          </motion.div>

          {/* Hero Image */}
          <motion.div initial={{
          opacity: 0,
          scale: 0.8
        }} animate={{
          opacity: 1,
          scale: 1
        }} transition={{
          duration: 1,
          delay: 0.3
        }} className="mt-16">
            <img alt="Luxury car fleet showcase" className="w-full max-w-4xl mx-auto rounded-2xl shadow-2xl" src="https://images.unsplash.com/photo-1694025881942-b752102cee95" />
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <motion.div initial={{
          opacity: 0,
          y: 20
        }} whileInView={{
          opacity: 1,
          y: 0
        }} transition={{
          duration: 0.6
        }} className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4 gradient-text">Why Choose Us</h2>
            <p className="text-gray-300 text-lg max-w-2xl mx-auto">
              We provide exceptional service with attention to every detail
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => <motion.div key={index} initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.6,
            delay: index * 0.1
          }} className="admin-card text-center">
                <feature.icon className="h-12 w-12 text-blue-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-300">{feature.description}</p>
              </motion.div>)}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <motion.div initial={{
          opacity: 0,
          scale: 0.9
        }} whileInView={{
          opacity: 1,
          scale: 1
        }} transition={{
          duration: 0.6
        }} className="admin-card text-center max-w-3xl mx-auto">
            <h2 className="text-3xl font-bold mb-4 gradient-text">Ready to Book?</h2>
            <p className="text-gray-300 text-lg mb-8">
              Join thousands of satisfied customers who trust us for their transportation needs
            </p>
            <Button onClick={() => navigate('/book')} className="btn-primary text-lg px-8 py-4">
              <MapPin className="mr-2 h-5 w-5" />
              Start Booking
            </Button>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 border-t border-white/10">
        <div className="container mx-auto text-center">
          <p className="text-gray-400">© 2025 Chitrakoot Tour And Travels. All rights reserved.
Developed & maintained By:- JKIT Software Group-9893823746
        </p>
        </div>
      </footer>
    </div>;
};
export default HomePage;