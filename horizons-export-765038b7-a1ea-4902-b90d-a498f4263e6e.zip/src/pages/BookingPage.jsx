import React, { useState, useContext, useEffect } from 'react';
    import { motion } from 'framer-motion';
    import { useNavigate } from 'react-router-dom';
    import { ArrowLeft, Car, Calendar, MapPin, User } from 'lucide-react';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
    import { toast } from '@/components/ui/use-toast';
    import { CarContext } from '@/context/CarContext';

    const BookingPage = () => {
      const navigate = useNavigate();
      const { carTypes, refreshCarTypes } = useContext(CarContext);
      const [formData, setFormData] = useState({
        customerName: '',
        mobileNo: '',
        email: '',
        pickupLocation: '',
        destination: '',
        date: '',
        time: '',
        carType: '',
        passengers: '',
        specialRequests: ''
      });

      useEffect(() => {
        refreshCarTypes();
      }, [refreshCarTypes]);

      const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
          ...prev,
          [name]: value
        }));
      };

      const handleSelectChange = (value) => {
        setFormData(prev => ({
          ...prev,
          carType: value
        }));
      };

      const handleSubmit = (e) => {
        e.preventDefault();
        
        if (!formData.customerName || !formData.mobileNo || !formData.pickupLocation || 
            !formData.destination || !formData.date || !formData.time || !formData.carType) {
          toast({
            title: "Missing Information",
            description: "Please fill in all required fields",
            variant: "destructive"
          });
          return;
        }

        const bookingId = 'CB' + Date.now().toString().slice(-6);
        const selectedCar = carTypes.find(car => car.name === formData.carType);
        
        const booking = {
          ...formData,
          bookingId,
          status: 'Confirmed',
          createdAt: new Date().toISOString(),
          totalAmount: selectedCar ? selectedCar.rate : 0
        };

        const existingBookings = JSON.parse(localStorage.getItem('carBookings') || '[]');
        existingBookings.push(booking);
        localStorage.setItem('carBookings', JSON.stringify(existingBookings));

        toast({
          title: "Booking Confirmed! 🎉",
          description: `Your booking ID is ${bookingId}. We'll contact you shortly!`
        });

        setFormData({
          customerName: '',
          mobileNo: '',
          email: '',
          pickupLocation: '',
          destination: '',
          date: '',
          time: '',
          carType: '',
          passengers: '',
          specialRequests: ''
        });
      };

      const getSelectedCarRate = () => {
        if (!formData.carType) return 0;
        const selectedCar = carTypes.find(car => car.name === formData.carType);
        return selectedCar ? selectedCar.rate : 0;
      };

      return (
        <div className="min-h-screen py-8 px-4">
          <div className="container mx-auto mb-8">
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-center gap-4 mb-6"
            >
              <Button
                variant="ghost"
                onClick={() => navigate('/')}
                className="text-white hover:bg-white/10"
              >
                <ArrowLeft className="h-5 w-5 mr-2" />
                Back to Home
              </Button>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center mb-8"
            >
              <h1 className="text-4xl font-bold gradient-text mb-4">Book Your Ride</h1>
              <p className="text-gray-300 text-lg">Fill in the details below to confirm your booking</p>
            </motion.div>
          </div>

          <div className="container mx-auto max-w-4xl">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              className="admin-card"
            >
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <h2 className="text-2xl font-semibold mb-4 flex items-center">
                    <User className="h-6 w-6 mr-2 text-blue-400" />
                    Customer Information
                  </h2>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="customerName" className="text-white">Full Name *</Label>
                      <Input
                        id="customerName"
                        name="customerName"
                        value={formData.customerName}
                        onChange={handleInputChange}
                        className="input-field mt-1"
                        placeholder="Enter your full name"
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="mobileNo" className="text-white">Mobile Number *</Label>
                      <Input
                        id="mobileNo"
                        name="mobileNo"
                        value={formData.mobileNo}
                        onChange={handleInputChange}
                        className="input-field mt-1"
                        placeholder="+91 98765 43210"
                        required
                      />
                    </div>
                    <div className="md:col-span-2">
                      <Label htmlFor="email" className="text-white">Email Address</Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        className="input-field mt-1"
                        placeholder="your.email@example.com"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <h2 className="text-2xl font-semibold mb-4 flex items-center">
                    <MapPin className="h-6 w-6 mr-2 text-blue-400" />
                    Trip Details
                  </h2>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="pickupLocation" className="text-white">Pickup Location *</Label>
                      <Input
                        id="pickupLocation"
                        name="pickupLocation"
                        value={formData.pickupLocation}
                        onChange={handleInputChange}
                        className="input-field mt-1"
                        placeholder="Enter pickup address"
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="destination" className="text-white">Destination *</Label>
                      <Input
                        id="destination"
                        name="destination"
                        value={formData.destination}
                        onChange={handleInputChange}
                        className="input-field mt-1"
                        placeholder="Enter destination address"
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="date" className="text-white">Date *</Label>
                      <Input
                        id="date"
                        name="date"
                        type="date"
                        value={formData.date}
                        onChange={handleInputChange}
                        className="input-field mt-1"
                        min={new Date().toISOString().split('T')[0]}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="time" className="text-white">Time *</Label>
                      <Input
                        id="time"
                        name="time"
                        type="time"
                        value={formData.time}
                        onChange={handleInputChange}
                        className="input-field mt-1"
                        required
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <h2 className="text-2xl font-semibold mb-4 flex items-center">
                    <Car className="h-6 w-6 mr-2 text-blue-400" />
                    Vehicle Selection
                  </h2>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="carType" className="text-white">Car Type *</Label>
                      <Select onValueChange={handleSelectChange} value={formData.carType}>
                        <SelectTrigger className="input-field mt-1">
                          <SelectValue placeholder="Select car type" />
                        </SelectTrigger>
                        <SelectContent>
                          {carTypes.map(car => (
                            <SelectItem key={car.id} value={car.name} className="bg-gray-800 text-white focus:bg-gray-700">
                              {car.name} - ₹{car.rate}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="passengers" className="text-white">Number of Passengers</Label>
                      <Input
                        id="passengers"
                        name="passengers"
                        type="number"
                        value={formData.passengers}
                        onChange={handleInputChange}
                        className="input-field mt-1"
                        placeholder="1-8 passengers"
                        min="1"
                        max="8"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <Label htmlFor="specialRequests" className="text-white">Special Requests</Label>
                  <textarea
                    id="specialRequests"
                    name="specialRequests"
                    value={formData.specialRequests}
                    onChange={handleInputChange}
                    className="input-field mt-1 h-24 resize-none"
                    placeholder="Any special requirements or notes..."
                  />
                </div>

                {formData.carType && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="glass-effect rounded-lg p-4 text-center"
                  >
                    <p className="text-lg">
                      Estimated Price: <span className="text-2xl font-bold text-green-400">
                        ₹{getSelectedCarRate()}
                      </span>
                    </p>
                  </motion.div>
                )}

                <div className="text-center pt-4">
                  <Button
                    type="submit"
                    className="btn-primary text-lg px-12 py-4"
                  >
                    <Calendar className="mr-2 h-5 w-5" />
                    Confirm Booking
                  </Button>
                </div>
              </form>
            </motion.div>
          </div>
        </div>
      );
    };

    export default BookingPage;