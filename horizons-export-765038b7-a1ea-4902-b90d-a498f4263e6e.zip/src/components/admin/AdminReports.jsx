import React from 'react';
import { BarChart3 } from 'lucide-react';

const AdminReports = ({ bookings }) => {
  const totalRevenue = bookings.reduce((sum, b) => sum + (b.totalAmount || 0), 0);

  const carTypePerformance = bookings.reduce((acc, booking) => {
    acc[booking.carType] = (acc[booking.carType] || 0) + 1;
    return acc;
  }, {});

  return (
    <div className="grid md:grid-cols-2 gap-6">
      <div className="admin-card">
        <h3 className="text-xl font-semibold mb-4 flex items-center">
          <BarChart3 className="h-5 w-5 mr-2 text-blue-400" />
          Revenue Overview
        </h3>
        <div className="h-64 flex items-center justify-center border-2 border-dashed border-white/20 rounded-lg">
          <div className="text-center text-gray-400">
            <BarChart3 className="h-12 w-12 mx-auto mb-2 opacity-50" />
            <p>Revenue chart visualization</p>
            <p className="text-sm">Total: ₹{totalRevenue.toLocaleString('en-IN')}</p>
          </div>
        </div>
      </div>

      <div className="admin-card">
        <h3 className="text-xl font-semibold mb-4">Car Type Performance</h3>
        <div className="space-y-3">
          {Object.entries(carTypePerformance).map(([carType, count]) => (
            <div key={carType} className="flex justify-between items-center">
              <span className="text-sm">{carType}</span>
              <div className="flex items-center gap-2">
                <div className="w-20 bg-white/10 rounded-full h-2">
                  <div 
                    className="bg-blue-500 h-2 rounded-full"
                    style={{ width: `${(count / bookings.length) * 100}%` }}
                  />
                </div>
                <span className="text-sm font-semibold w-8">{count}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AdminReports;