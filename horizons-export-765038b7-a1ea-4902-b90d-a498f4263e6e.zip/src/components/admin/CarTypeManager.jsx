import React, { useState, useContext } from 'react';
import { Car, Plus, Edit, Trash2, Save } from 'lucide-react';
import { CarContext } from '@/context/CarContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from '@/components/ui/use-toast';

const CarTypeManager = () => {
  const { carTypes, addCarType, updateCarType, deleteCarType } = useContext(CarContext);
  const [newCar, setNewCar] = useState({ name: '', rate: '' });
  const [editingCar, setEditingCar] = useState(null);

  const handleAddCar = () => {
    if (newCar.name && newCar.rate) {
      addCarType({ name: newCar.name, rate: parseFloat(newCar.rate) });
      setNewCar({ name: '', rate: '' });
      toast({ title: "Success", description: "New car type added." });
    } else {
      toast({ title: "Error", description: "Please provide name and rate.", variant: "destructive" });
    }
  };

  const handleUpdateCar = () => {
    if (editingCar && editingCar.name && editingCar.rate) {
      updateCarType({ ...editingCar, rate: parseFloat(editingCar.rate) });
      setEditingCar(null);
      toast({ title: "Success", description: "Car type updated." });
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h3 className="text-xl font-semibold mb-4 flex items-center">
          <Plus className="h-5 w-5 mr-2 text-blue-400" />
          Add New Car Type
        </h3>
        <div className="flex flex-col sm:flex-row gap-4 items-end">
          <div className="flex-1 w-full">
            <Label htmlFor="newCarName">Car Name</Label>
            <Input id="newCarName" value={newCar.name} onChange={(e) => setNewCar({ ...newCar, name: e.target.value })} placeholder="e.g., Premium Sedan" className="input-field mt-1" />
          </div>
          <div className="flex-1 w-full">
            <Label htmlFor="newCarRate">Rate (₹)</Label>
            <Input id="newCarRate" type="number" value={newCar.rate} onChange={(e) => setNewCar({ ...newCar, rate: e.target.value })} placeholder="e.g., 800" className="input-field mt-1" />
          </div>
          <Button onClick={handleAddCar} className="btn-primary w-full sm:w-auto"><Plus className="h-4 w-4 mr-2" />Add Car</Button>
        </div>
      </div>

      <div>
        <h3 className="text-xl font-semibold mb-4 flex items-center">
          <Car className="h-5 w-5 mr-2 text-blue-400" />
          Manage Car Types
        </h3>
        <div className="space-y-4">
          {carTypes.map(car => (
            <div key={car.id} className="flex items-center justify-between p-4 bg-white/5 rounded-lg">
              {editingCar?.id === car.id ? (
                <>
                  <Input value={editingCar.name} onChange={(e) => setEditingCar({ ...editingCar, name: e.target.value })} className="input-field w-1/3" />
                  <Input type="number" value={editingCar.rate} onChange={(e) => setEditingCar({ ...editingCar, rate: e.target.value })} className="input-field w-1/4" />
                  <div className="flex gap-2">
                    <Button size="sm" onClick={handleUpdateCar} className="bg-green-600 hover:bg-green-700"><Save className="h-4 w-4" /></Button>
                    <Button size="sm" variant="ghost" onClick={() => setEditingCar(null)}>Cancel</Button>
                  </div>
                </>
              ) : (
                <>
                  <div>
                    <p className="font-semibold">{car.name}</p>
                    <p className="text-sm text-green-400">₹{car.rate}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="ghost" onClick={() => setEditingCar(car)}><Edit className="h-4 w-4" /></Button>
                    <Button size="sm" variant="ghost" className="text-red-400 hover:text-red-500" onClick={() => deleteCarType(car.id)}><Trash2 className="h-4 w-4" /></Button>
                  </div>
                </>
              )}
            </div>
          ))}
        </div>
      </div>
      
      <div className="mt-8 p-4 bg-blue-900/50 border border-blue-700 rounded-lg">
        <h4 className="font-bold text-lg text-blue-300">Ready for a Real Database?</h4>
        <p className="text-blue-300/80 mt-2">
          Currently, your car types and bookings are saved in your browser's local storage. For a real-world application, you'll need a persistent database.
        </p>
        <p className="text-blue-300/80 mt-2">
          I recommend using **Supabase**, a powerful and easy-to-use cloud database. When you're ready, just ask me to "integrate with Supabase"!
        </p>
        <Button onClick={() => toast({ title: "🚧 Feature Not Implemented", description: "You can request Supabase integration in your next prompt! 🚀"})} className="mt-4 btn-secondary">
          Learn More about Supabase
        </Button>
      </div>
    </div>
  );
};

export default CarTypeManager;