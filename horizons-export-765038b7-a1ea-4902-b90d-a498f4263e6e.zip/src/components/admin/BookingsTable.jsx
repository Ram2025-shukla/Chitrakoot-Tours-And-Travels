import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Search, Printer, Download, Share2, Trash2, Car } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from '@/components/ui/use-toast';

const BookingsTable = ({ bookings, onUpdate }) => {
  const [filteredBookings, setFilteredBookings] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [dateFilter, setDateFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');

  useEffect(() => {
    let filtered = bookings;
    if (searchTerm) {
      filtered = filtered.filter(b => 
        b.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        b.mobileNo.includes(searchTerm) ||
        b.bookingId.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    if (dateFilter) {
      filtered = filtered.filter(b => b.date === dateFilter);
    }
    if (statusFilter) {
      filtered = filtered.filter(b => b.status === statusFilter);
    }
    setFilteredBookings(filtered);
  }, [bookings, searchTerm, dateFilter, statusFilter]);

  const handleDeleteBooking = (bookingId) => {
    const updatedBookings = bookings.filter(b => b.bookingId !== bookingId);
    localStorage.setItem('carBookings', JSON.stringify(updatedBookings));
    onUpdate();
    toast({ title: "Booking Deleted", description: "Booking has been successfully deleted" });
  };

  const handlePrint = () => window.print();

  const handleExport = () => {
    const csvContent = [
      ['Booking ID', 'Customer Name', 'Mobile', 'Pickup', 'Destination', 'Date', 'Time', 'Car Type', 'Amount', 'Status'],
      ...filteredBookings.map(b => [b.bookingId, b.customerName, b.mobileNo, b.pickupLocation, b.destination, b.date, b.time, b.carType, b.totalAmount, b.status])
    ].map(row => row.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bookings-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
    toast({ title: "Export Successful! 📊", description: "Bookings data has been exported to CSV" });
  };

  const handleWhatsAppShare = (booking) => {
    const message = `🚗 *Booking Confirmation*\n\n` +
      `📋 Booking ID: ${booking.bookingId}\n` +
      `👤 Customer: ${booking.customerName}\n` +
      `📱 Mobile: ${booking.mobileNo}\n` +
      `📍 Pickup: ${booking.pickupLocation}\n` +
      `🎯 Destination: ${booking.destination}\n` +
      `📅 Date: ${booking.date}\n` +
      `⏰ Time: ${booking.time}\n` +
      `🚙 Car Type: ${booking.carType}\n` +
      `💰 Amount: ₹${booking.totalAmount}\n` +
      `✅ Status: ${booking.status}`;
    const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-center justify-between">
        <div className="flex flex-col sm:flex-row gap-4 flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            <Input placeholder="Search..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="input-field pl-10 w-full sm:w-64" />
          </div>
          <Input type="date" value={dateFilter} onChange={(e) => setDateFilter(e.target.value)} className="input-field" />
          <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="input-field">
            <option value="">All Status</option>
            <option value="Confirmed">Confirmed</option>
            <option value="Pending">Pending</option>
            <option value="Completed">Completed</option>
            <option value="Cancelled">Cancelled</option>
          </select>
        </div>
        <div className="flex gap-2 no-print">
          <Button onClick={handlePrint} variant="outline" className="border-white/30"><Printer className="h-4 w-4 mr-2" />Print</Button>
          <Button onClick={handleExport} variant="outline" className="border-white/30"><Download className="h-4 w-4 mr-2" />Export</Button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-white/20">
              <th className="p-3 text-left text-gray-300">Booking ID</th>
              <th className="p-3 text-left text-gray-300">Customer</th>
              <th className="p-3 text-left text-gray-300">Route</th>
              <th className="p-3 text-left text-gray-300">Date & Time</th>
              <th className="p-3 text-left text-gray-300">Amount</th>
              <th className="p-3 text-left text-gray-300">Status</th>
              <th className="p-3 text-left text-gray-300 no-print">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredBookings.map((booking, index) => (
              <motion.tr key={booking.bookingId} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.05 }} className="border-b border-white/10 hover:bg-white/5">
                <td className="p-3 font-mono text-blue-400">{booking.bookingId}</td>
                <td className="p-3">{booking.customerName}<br/><span className="text-xs text-gray-400">{booking.mobileNo}</span></td>
                <td className="p-3 text-xs">From: {booking.pickupLocation}<br/>To: {booking.destination}</td>
                <td className="p-3 text-xs">{booking.date}<br/>{booking.time}</td>
                <td className="p-3 text-green-400 font-semibold">₹{booking.totalAmount}</td>
                <td className="p-3">
                  <span className={`px-2 py-1 rounded-full text-xs ${booking.status === 'Confirmed' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>{booking.status}</span>
                </td>
                <td className="p-3 no-print">
                  <div className="flex gap-1">
                    <Button size="sm" variant="ghost" onClick={() => handleWhatsAppShare(booking)} className="text-green-400 hover:bg-green-500/10"><Share2 className="h-4 w-4" /></Button>
                    <Button size="sm" variant="ghost" onClick={() => handleDeleteBooking(booking.bookingId)} className="text-red-400 hover:bg-red-500/10"><Trash2 className="h-4 w-4" /></Button>
                  </div>
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
        {filteredBookings.length === 0 && (
          <div className="text-center py-12 text-gray-400"><Car className="h-12 w-12 mx-auto mb-4 opacity-50" /><p>No bookings found</p></div>
        )}
      </div>
    </div>
  );
};

export default BookingsTable;