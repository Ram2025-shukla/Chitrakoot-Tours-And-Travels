import React from 'react';
import { motion } from 'framer-motion';
import { Car, DollarSign, Calendar, TrendingUp } from 'lucide-react';

const AdminStats = ({ bookings }) => {
  const getStats = () => {
    const totalBookings = bookings.length;
    const totalRevenue = bookings.reduce((sum, booking) => sum + (booking.totalAmount || 0), 0);
    const todayBookings = bookings.filter(booking => booking.date === new Date().toISOString().split('T')[0]).length;
    const confirmedBookings = bookings.filter(booking => booking.status === 'Confirmed').length;
    return { totalBookings, totalRevenue, todayBookings, confirmedBookings };
  };

  const stats = getStats();

  const statCards = [
    { icon: Car, value: stats.totalBookings, label: 'Total Bookings', color: 'blue' },
    { icon: DollarSign, value: `₹${stats.totalRevenue.toLocaleString('en-IN')}`, label: 'Total Revenue', color: 'green' },
    { icon: Calendar, value: stats.todayBookings, label: "Today's Bookings", color: 'purple' },
    { icon: TrendingUp, value: stats.confirmedBookings, label: 'Confirmed', color: 'orange' },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {statCards.map((card, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: index * 0.1 }}
          className="admin-card text-center"
        >
          <card.icon className={`h-8 w-8 text-${card.color}-400 mx-auto mb-2`} />
          <p className={`text-2xl font-bold text-${card.color}-400`}>{card.value}</p>
          <p className="text-gray-300">{card.label}</p>
        </motion.div>
      ))}
    </div>
  );
};

export default AdminStats;