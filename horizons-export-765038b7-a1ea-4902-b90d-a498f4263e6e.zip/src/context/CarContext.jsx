import React, { createContext, useState, useEffect, useCallback } from 'react';

export const CarContext = createContext();

const defaultCarTypes = [
  { id: 'ct1', name: 'Economy Car', rate: 500 },
  { id: 'ct2', name: 'Premium Sedan', rate: 800 },
  { id: 'ct3', name: 'Luxury SUV', rate: 1200 },
  { id: 'ct4', name: 'Executive Car', rate: 1000 },
  { id: 'ct5', name: 'Mini Van', rate: 900 },
  { id: 'ct6', name: 'Luxury Limousine', rate: 2000 },
];

export const CarProvider = ({ children }) => {
  const [carTypes, setCarTypes] = useState(() => {
    try {
      const localData = localStorage.getItem('carTypesData');
      return localData ? JSON.parse(localData) : defaultCarTypes;
    } catch (error) {
      console.error("Error parsing car types from localStorage", error);
      return defaultCarTypes;
    }
  });

  const refreshCarTypes = useCallback(() => {
    try {
      const localData = localStorage.getItem('carTypesData');
      if (localData) {
        setCarTypes(JSON.parse(localData));
      }
    } catch (error) {
      console.error("Error refreshing car types from localStorage", error);
    }
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem('carTypesData', JSON.stringify(carTypes));
    } catch (error) {
      console.error("Error saving car types to localStorage", error);
    }
  }, [carTypes]);

  const addCarType = (car) => {
    setCarTypes(prev => [...prev, { ...car, id: `ct${Date.now()}` }]);
  };

  const updateCarType = (updatedCar) => {
    setCarTypes(prev => prev.map(car => car.id === updatedCar.id ? updatedCar : car));
  };

  const deleteCarType = (carId) => {
    setCarTypes(prev => prev.filter(car => car.id !== carId));
  };

  return (
    <CarContext.Provider value={{ carTypes, addCarType, updateCarType, deleteCarType, refreshCarTypes }}>
      {children}
    </CarContext.Provider>
  );
};