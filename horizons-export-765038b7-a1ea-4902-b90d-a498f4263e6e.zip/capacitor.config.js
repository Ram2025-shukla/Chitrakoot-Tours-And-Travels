export default {
  appId: 'com.jkit.chitrakoot.travels',
  appName: 'Chitrakoot Tour and Travels',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  }
};